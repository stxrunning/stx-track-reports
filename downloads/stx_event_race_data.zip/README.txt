Saint Xavier Track & Cross-Country Event and Race Data
======================================================

Result rows: 92,252
Race/event rows: 2,346
Race dates: 1950-05-20 through 2026-09-23

Files
-----
stx_results.csv: One row per stored result, including splits and source links.
stx_race_events.csv: One row per race/event/division combination.
data_dictionary.csv: Column descriptions for the results file.

Notes
-----
This is a normalized historical dataset assembled from multiple public sources.
Blank values indicate that a field was not available or did not apply.
Times in numeric fields are expressed in seconds.
total_time_text and split_text use mm:ss.00 (minutes:seconds.hundredths).
